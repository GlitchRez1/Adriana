package org.LP2;

public class Esperanca {

    private Integer id;
    private int brilho;         // UML: brilho : int
    private int frequencia;     // UML: frequência : int
    private String fonte;       // UML: fonte : String

    public Esperanca() {
    }

    public Esperanca(Integer id, int brilho, int frequencia, String fonte) {
        this.id = id;
        this.brilho = brilho;
        this.frequencia = frequencia;
        this.fonte = fonte;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getBrilho() {
        return brilho;
    }

    public void setBrilho(int brilho) {
        this.brilho = brilho;
    }

    public int getFrequencia() {
        return frequencia;
    }

    public void setFrequencia(int frequencia) {
        this.frequencia = frequencia;
    }

    public String getFonte() {
        return fonte;
    }

    public void setFonte(String fonte) {
        this.fonte = fonte;
    }

    // Método da UML

    public void prevalecer() {
        this.brilho += 5;
        this.frequencia += 1;
    }

    @Override
    public String toString() {
        return "Esperanca{" +
                "id=" + id +
                ", brilho=" + brilho +
                ", frequencia=" + frequencia +
                ", fonte='" + fonte + '\'' +
                '}';
    }
}
