package org.LP2;

public class Luta {

    private Integer id;            // para o banco
    private boolean finalizada;    // UML: final : boolean
    private int oponentes;         // UML: oponentes : int
    private String local;          // UML: local : String

    public Luta() {
    }

    public Luta(boolean finalizada, int oponentes, String local) {
        this(null, finalizada, oponentes, local);
    }

    public Luta(Integer id, boolean finalizada, int oponentes, String local) {
        this.id = id;
        this.finalizada = finalizada;
        this.oponentes = oponentes;
        this.local = local;
    }

    public void iniciarLuta() {
        this.finalizada = false;
        System.out.println("Luta iniciada em " + local + " contra " + oponentes + " oponente(s).");
    }

    // Getters / Setters

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public boolean isFinalizada() {
        return finalizada;
    }

    public void setFinalizada(boolean finalizada) {
        this.finalizada = finalizada;
    }

    public int getOponentes() {
        return oponentes;
    }

    public void setOponentes(int oponentes) {
        this.oponentes = oponentes;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    @Override
    public String toString() {
        return "Luta{" +
                "id=" + id +
                ", finalizada=" + finalizada +
                ", oponentes=" + oponentes +
                ", local='" + local + '\'' +
                '}';
    }
}
