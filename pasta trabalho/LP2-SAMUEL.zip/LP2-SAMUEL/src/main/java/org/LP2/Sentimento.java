package org.LP2;

public class Sentimento {

    private Integer id;
    private double peso;         // UML: peso : double
    private int intensidade;     // UML: intensidade : int
    private String motivo;       // UML: motivo : String

    public Sentimento() {
    }

    public Sentimento(Integer id, double peso, int intensidade, String motivo) {
        this.id = id;
        this.peso = peso;
        this.intensidade = intensidade;
        this.motivo = motivo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public int getIntensidade() {
        return intensidade;
    }

    public void setIntensidade(int intensidade) {
        this.intensidade = intensidade;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    // Métodos da UML

    public void enfurecer() {
        this.intensidade += 10;
        this.peso += 1.5;
    }

    public void felicidade() {
        if (this.intensidade > 0) this.intensidade -= 5;
        if (this.peso > 0) this.peso -= 0.5;
    }

    @Override
    public String toString() {
        return "Sentimento{" +
                "id=" + id +
                ", peso=" + peso +
                ", intensidade=" + intensidade +
                ", motivo='" + motivo + '\'' +
                '}';
    }
}
