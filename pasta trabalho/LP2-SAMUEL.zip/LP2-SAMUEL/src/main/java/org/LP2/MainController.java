package org.LP2;

import org.LP2.DAO.EsperancaDAO;
import org.LP2.DAO.LutaDAO;
import org.LP2.DAO.SentimentoDAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class MainController {

    // --- LUTA ---

    @FXML private CheckBox lutaFinalizadaCheck;
    @FXML private TextField lutaOponentesField;
    @FXML private TextField lutaLocalField;

    @FXML private TableView<Luta> lutaTable;
    @FXML private TableColumn<Luta, Integer> lutaIdCol;
    @FXML private TableColumn<Luta, Boolean> lutaFinalizadaCol;
    @FXML private TableColumn<Luta, Integer> lutaOponentesCol;
    @FXML private TableColumn<Luta, String> lutaLocalCol;

    private final LutaDAO lutaDAO = new LutaDAO();
    private final ObservableList<Luta> lutas = FXCollections.observableArrayList();
    private Luta lutaSelecionada;

    // --- SENTIMENTO ---

    @FXML private TextField sentimentoPesoField;
    @FXML private TextField sentimentoIntensidadeField;
    @FXML private TextField sentimentoMotivoField;

    @FXML private TableView<Sentimento> sentimentoTable;
    @FXML private TableColumn<Sentimento, Integer> sentimentoIdCol;
    @FXML private TableColumn<Sentimento, Double> sentimentoPesoCol;
    @FXML private TableColumn<Sentimento, Integer> sentimentoIntensidadeCol;
    @FXML private TableColumn<Sentimento, String> sentimentoMotivoCol;

    private final SentimentoDAO sentimentoDAO = new SentimentoDAO();
    private final ObservableList<Sentimento> sentimentos = FXCollections.observableArrayList();
    private Sentimento sentimentoSelecionado;

    // --- ESPERANÇA ---

    @FXML private TextField esperancaBrilhoField;
    @FXML private TextField esperancaFrequenciaField;
    @FXML private TextField esperancaFonteField;

    @FXML private TableView<Esperanca> esperancaTable;
    @FXML private TableColumn<Esperanca, Integer> esperancaIdCol;
    @FXML private TableColumn<Esperanca, Integer> esperancaBrilhoCol;
    @FXML private TableColumn<Esperanca, Integer> esperancaFrequenciaCol;
    @FXML private TableColumn<Esperanca, String> esperancaFonteCol;

    private final EsperancaDAO esperancaDAO = new EsperancaDAO();
    private final ObservableList<Esperanca> esperancas = FXCollections.observableArrayList();
    private Esperanca esperancaSelecionada;

    public MainController() {
    }

    @FXML
    public void initialize() {
        initTabelaLuta();
        initTabelaSentimento();
        initTabelaEsperanca();
    }

    // --------- LUTA ---------

    private void initTabelaLuta() {
        lutaIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        lutaFinalizadaCol.setCellValueFactory(new PropertyValueFactory<>("finalizada"));
        lutaOponentesCol.setCellValueFactory(new PropertyValueFactory<>("oponentes"));
        lutaLocalCol.setCellValueFactory(new PropertyValueFactory<>("local"));

        lutaTable.setItems(lutas);
        lutas.setAll(lutaDAO.listarTodos());

        lutaTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSel, newSel) -> {
                    lutaSelecionada = newSel;
                    preencherFormLuta(newSel);
                });
    }

    private void preencherFormLuta(Luta l) {
        if (l == null) {
            lutaFinalizadaCheck.setSelected(false);
            lutaOponentesField.clear();
            lutaLocalField.clear();
        } else {
            lutaFinalizadaCheck.setSelected(l.isFinalizada());
            lutaOponentesField.setText(String.valueOf(l.getOponentes()));
            lutaLocalField.setText(l.getLocal());
        }
    }

    @FXML
    private void onNovaLuta() {
        lutaSelecionada = null;
        preencherFormLuta(null);
    }

    @FXML
    private void onSalvarLuta() {
        String oponentesStr = lutaOponentesField.getText();
        String local = lutaLocalField.getText();

        if (oponentesStr.isBlank() || local.isBlank()) {
            showAlert("Informe o número de oponentes e o local da luta.");
            return;
        }

        int oponentes;
        try {
            oponentes = Integer.parseInt(oponentesStr);
        } catch (NumberFormatException e) {
            showAlert("Oponentes deve ser um número inteiro.");
            return;
        }

        boolean finalizada = lutaFinalizadaCheck.isSelected();

        if (lutaSelecionada == null) {
            lutaSelecionada = new Luta(null, finalizada, oponentes, local);
        } else {
            lutaSelecionada.setFinalizada(finalizada);
            lutaSelecionada.setOponentes(oponentes);
            lutaSelecionada.setLocal(local);
        }

        lutaDAO.salvar(lutaSelecionada);
        lutas.setAll(lutaDAO.listarTodos());
        preencherFormLuta(null);
        lutaSelecionada = null;
    }

    @FXML
    private void onExcluirLuta() {
        if (lutaSelecionada == null) {
            showAlert("Selecione uma Luta para excluir.");
            return;
        }
        lutaDAO.deletar(lutaSelecionada);
        lutas.setAll(lutaDAO.listarTodos());
        preencherFormLuta(null);
        lutaSelecionada = null;
    }

    // --------- SENTIMENTO ---------

    private void initTabelaSentimento() {
        sentimentoIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        sentimentoPesoCol.setCellValueFactory(new PropertyValueFactory<>("peso"));
        sentimentoIntensidadeCol.setCellValueFactory(new PropertyValueFactory<>("intensidade"));
        sentimentoMotivoCol.setCellValueFactory(new PropertyValueFactory<>("motivo"));

        sentimentoTable.setItems(sentimentos);
        sentimentos.setAll(sentimentoDAO.listarTodos());

        sentimentoTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSel, newSel) -> {
                    sentimentoSelecionado = newSel;
                    preencherFormSentimento(newSel);
                });
    }

    private void preencherFormSentimento(Sentimento s) {
        if (s == null) {
            sentimentoPesoField.clear();
            sentimentoIntensidadeField.clear();
            sentimentoMotivoField.clear();
        } else {
            sentimentoPesoField.setText(String.valueOf(s.getPeso()));
            sentimentoIntensidadeField.setText(String.valueOf(s.getIntensidade()));
            sentimentoMotivoField.setText(s.getMotivo());
        }
    }

    @FXML
    private void onNovoSentimento() {
        sentimentoSelecionado = null;
        preencherFormSentimento(null);
    }

    @FXML
    private void onSalvarSentimento() {
        String pesoStr = sentimentoPesoField.getText();
        String intensidadeStr = sentimentoIntensidadeField.getText();
        String motivo = sentimentoMotivoField.getText();

        if (pesoStr.isBlank() || intensidadeStr.isBlank() || motivo.isBlank()) {
            showAlert("Preencha todos os campos de Sentimento.");
            return;
        }

        double peso;
        int intensidade;
        try {
            peso = Double.parseDouble(pesoStr);
            intensidade = Integer.parseInt(intensidadeStr);
        } catch (NumberFormatException e) {
            showAlert("Peso deve ser decimal e intensidade deve ser inteira.");
            return;
        }

        if (sentimentoSelecionado == null) {
            sentimentoSelecionado = new Sentimento(null, peso, intensidade, motivo);
        } else {
            sentimentoSelecionado.setPeso(peso);
            sentimentoSelecionado.setIntensidade(intensidade);
            sentimentoSelecionado.setMotivo(motivo);
        }

        sentimentoDAO.salvar(sentimentoSelecionado);
        sentimentos.setAll(sentimentoDAO.listarTodos());
        preencherFormSentimento(null);
        sentimentoSelecionado = null;
    }

    @FXML
    private void onExcluirSentimento() {
        if (sentimentoSelecionado == null) {
            showAlert("Selecione um Sentimento para excluir.");
            return;
        }
        sentimentoDAO.deletar(sentimentoSelecionado);
        sentimentos.setAll(sentimentoDAO.listarTodos());
        preencherFormSentimento(null);
        sentimentoSelecionado = null;
    }

    // --------- ESPERANÇA ---------

    private void initTabelaEsperanca() {
        esperancaIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        esperancaBrilhoCol.setCellValueFactory(new PropertyValueFactory<>("brilho"));
        esperancaFrequenciaCol.setCellValueFactory(new PropertyValueFactory<>("frequencia"));
        esperancaFonteCol.setCellValueFactory(new PropertyValueFactory<>("fonte"));

        esperancaTable.setItems(esperancas);
        esperancas.setAll(esperancaDAO.listarTodos());

        esperancaTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSel, newSel) -> {
                    esperancaSelecionada = newSel;
                    preencherFormEsperanca(newSel);
                });
    }

    private void preencherFormEsperanca(Esperanca e) {
        if (e == null) {
            esperancaBrilhoField.clear();
            esperancaFrequenciaField.clear();
            esperancaFonteField.clear();
        } else {
            esperancaBrilhoField.setText(String.valueOf(e.getBrilho()));
            esperancaFrequenciaField.setText(String.valueOf(e.getFrequencia()));
            esperancaFonteField.setText(e.getFonte());
        }
    }

    @FXML
    private void onNovaEsperanca() {
        esperancaSelecionada = null;
        preencherFormEsperanca(null);
    }

    @FXML
    private void onSalvarEsperanca() {
        String brilhoStr = esperancaBrilhoField.getText();
        String freqStr = esperancaFrequenciaField.getText();
        String fonte = esperancaFonteField.getText();

        if (brilhoStr.isBlank() || freqStr.isBlank() || fonte.isBlank()) {
            showAlert("Preencha todos os campos de Esperança.");
            return;
        }

        int brilho;
        int frequencia;
        try {
            brilho = Integer.parseInt(brilhoStr);
            frequencia = Integer.parseInt(freqStr);
        } catch (NumberFormatException e) {
            showAlert("Brilho e frequência devem ser inteiros.");
            return;
        }

        if (esperancaSelecionada == null) {
            esperancaSelecionada = new Esperanca(null, brilho, frequencia, fonte);
        } else {
            esperancaSelecionada.setBrilho(brilho);
            esperancaSelecionada.setFrequencia(frequencia);
            esperancaSelecionada.setFonte(fonte);
        }

        esperancaDAO.salvar(esperancaSelecionada);
        esperancas.setAll(esperancaDAO.listarTodos());
        preencherFormEsperanca(null);
        esperancaSelecionada = null;
    }

    @FXML
    private void onExcluirEsperanca() {
        if (esperancaSelecionada == null) {
            showAlert("Selecione uma Esperança para excluir.");
            return;
        }
        esperancaDAO.deletar(esperancaSelecionada);
        esperancas.setAll(esperancaDAO.listarTodos());
        preencherFormEsperanca(null);
        esperancaSelecionada = null;
    }

    // --------- UTIL ---------

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Aviso");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
