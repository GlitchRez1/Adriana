package org.LP2.DAO;

import org.LP2.BD.Database;
import org.LP2.Sentimento;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SentimentoDAO {

    public void salvar(Sentimento sentimento) {
        if (sentimento.getId() == null) {
            inserir(sentimento);
        } else {
            atualizar(sentimento);
        }
    }

    private void inserir(Sentimento sentimento) {
        String sql = "INSERT INTO sentimento (peso, intensidade, motivo) VALUES (?, ?, ?)";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setDouble(1, sentimento.getPeso());
            ps.setInt(2, sentimento.getIntensidade());
            ps.setString(3, sentimento.getMotivo());
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    sentimento.setId(rs.getInt(1));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void atualizar(Sentimento sentimento) {
        String sql = "UPDATE sentimento SET peso = ?, intensidade = ?, motivo = ? WHERE id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDouble(1, sentimento.getPeso());
            ps.setInt(2, sentimento.getIntensidade());
            ps.setString(3, sentimento.getMotivo());
            ps.setInt(4, sentimento.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletar(Sentimento sentimento) {
        if (sentimento.getId() == null) return;

        String sql = "DELETE FROM sentimento WHERE id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, sentimento.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Sentimento> listarTodos() {
        List<Sentimento> lista = new ArrayList<>();
        String sql = "SELECT id, peso, intensidade, motivo FROM sentimento";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Sentimento s = new Sentimento(
                        rs.getInt("id"),
                        rs.getDouble("peso"),
                        rs.getInt("intensidade"),
                        rs.getString("motivo")
                );
                lista.add(s);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
