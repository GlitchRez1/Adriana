package org.LP2.DAO;

import org.LP2.BD.Database;
import org.LP2.Luta;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LutaDAO {

    public void salvar(Luta luta) {
        if (luta.getId() == null) {
            inserir(luta);
        } else {
            atualizar(luta);
        }
    }

    private void inserir(Luta luta) {
        String sql = "INSERT INTO luta (finalizada, oponentes, local) VALUES (?, ?, ?)";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, luta.isFinalizada() ? 1 : 0);
            ps.setInt(2, luta.getOponentes());
            ps.setString(3, luta.getLocal());
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    luta.setId(rs.getInt(1));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void atualizar(Luta luta) {
        String sql = "UPDATE luta SET finalizada = ?, oponentes = ?, local = ? WHERE id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, luta.isFinalizada() ? 1 : 0);
            ps.setInt(2, luta.getOponentes());
            ps.setString(3, luta.getLocal());
            ps.setInt(4, luta.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletar(Luta luta) {
        if (luta.getId() == null) return;

        String sql = "DELETE FROM luta WHERE id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, luta.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Luta> listarTodos() {
        List<Luta> lista = new ArrayList<>();
        String sql = "SELECT id, finalizada, oponentes, local FROM luta";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Luta l = new Luta(
                        rs.getInt("id"),
                        rs.getInt("finalizada") == 1,
                        rs.getInt("oponentes"),
                        rs.getString("local")
                );
                lista.add(l);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
