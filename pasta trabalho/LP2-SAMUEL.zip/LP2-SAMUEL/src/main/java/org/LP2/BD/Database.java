package org.LP2.BD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {

    private static final String URL = "jdbc:sqlite:luta_sentimento_esperanca.db";

    static {
        try (Connection conn = getConnection();
             Statement st = conn.createStatement()) {

            st.execute("""
                    CREATE TABLE IF NOT EXISTS luta (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        finalizada INTEGER NOT NULL,
                        oponentes INTEGER NOT NULL,
                        local TEXT NOT NULL
                    )
                    """);

            st.execute("""
                    CREATE TABLE IF NOT EXISTS sentimento (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        peso REAL NOT NULL,
                        intensidade INTEGER NOT NULL,
                        motivo TEXT NOT NULL
                    )
                    """);

            st.execute("""
                    CREATE TABLE IF NOT EXISTS esperanca (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        brilho INTEGER NOT NULL,
                        frequencia INTEGER NOT NULL,
                        fonte TEXT NOT NULL
                    )
                    """);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }
}
