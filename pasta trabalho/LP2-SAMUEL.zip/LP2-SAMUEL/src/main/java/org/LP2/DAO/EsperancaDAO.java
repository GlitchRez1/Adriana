package org.LP2.DAO;

import org.LP2.BD.Database;
import org.LP2.Esperanca;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EsperancaDAO {

    public void salvar(Esperanca esperanca) {
        if (esperanca.getId() == null) {
            inserir(esperanca);
        } else {
            atualizar(esperanca);
        }
    }

    private void inserir(Esperanca esperanca) {
        String sql = "INSERT INTO esperanca (brilho, frequencia, fonte) VALUES (?, ?, ?)";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, esperanca.getBrilho());
            ps.setInt(2, esperanca.getFrequencia());
            ps.setString(3, esperanca.getFonte());
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    esperanca.setId(rs.getInt(1));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void atualizar(Esperanca esperanca) {
        String sql = "UPDATE esperanca SET brilho = ?, frequencia = ?, fonte = ? WHERE id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, esperanca.getBrilho());
            ps.setInt(2, esperanca.getFrequencia());
            ps.setString(3, esperanca.getFonte());
            ps.setInt(4, esperanca.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletar(Esperanca esperanca) {
        if (esperanca.getId() == null) return;

        String sql = "DELETE FROM esperanca WHERE id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, esperanca.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Esperanca> listarTodos() {
        List<Esperanca> lista = new ArrayList<>();
        String sql = "SELECT id, brilho, frequencia, fonte FROM esperanca";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Esperanca e = new Esperanca(
                        rs.getInt("id"),
                        rs.getInt("brilho"),
                        rs.getInt("frequencia"),
                        rs.getString("fonte")
                );
                lista.add(e);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
